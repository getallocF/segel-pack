# Segel Pack (Android)

Aplikasi Android (Java, tanpa library tambahan) dengan dua fitur:

1. **Server** – masukkan IP/host + port server Minecraft Java. Aplikasi mengecek status server,
   masuk sebagai pemain offline, menangkap tautan resource pack yang dikirim server (URL, SHA-1,
   wajib/tidak), lalu mengunduhnya ke `Download/SegelPack/` dan memverifikasi SHA-1.
2. **GitHub** – cari tools Minecraft di GitHub (kategori siap pakai atau kata kunci bebas),
   lihat detail, buka repo, dan unduh file dari release langsung ke `Download/SegelPack/`.

## Cara mendapatkan APK (tanpa PC) — lihat juga GUIA_GITHUB.md

1. Buat repo baru di github.com, unggah **seluruh isi** folder ini (termasuk `.github/`).
   Kalau folder `.github` tidak ikut terunggah, buat file `.github/workflows/build-apk.yml`
   lewat "Add file → Create new file" lalu tempel isi file yang sama.
2. Buka tab **Actions** → workflow **Build APK** → tunggu hijau (±4–6 menit).
   (Bisa juga dijalankan manual lewat "Run workflow".)
3. Buka run tersebut → bagian **Artifacts** → unduh `SegelPack-apk` → ekstrak → `app-debug.apk`.
4. Pasang di HP (izinkan "pasang dari sumber ini").

Atau buka folder ini di Android Studio dan pilih Build → Build APK(s).

## Batasan

- Pengambilan pack hanya untuk server Minecraft **Java**. Untuk Bedrock, aplikasi hanya menampilkan status server (MOTD, versi, pemain, ping); pengambilan pack Bedrock tidak didukung.
- Server **online-mode** (wajib akun premium) menolak aplikasi ini — akan muncul pesan jelas.
  Berfungsi untuk server offline-mode, LAN, atau server milikmu.
- Server yang tidak mengirim pack otomatis tidak akan menghasilkan apa-apa.
- Pakai untuk pack milikmu atau yang diizinkan pemiliknya.
- Pencarian GitHub tanpa login dibatasi ±10 permintaan per menit.

## Pengujian inti protokol (opsional, di PC dengan JDK 17+)

Folder `core-test/` berisi server Minecraft tiruan (`mock.py`) dan harness uji.
