import http.server, io, zipfile, socketserver
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w') as z: z.writestr('pack.mcmeta','{"pack":{"pack_format":34,"description":"x"}}')
data=buf.getvalue()
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(s):
        if s.path=='/redir': s.send_response(302); s.send_header('Location','/real.zip'); s.end_headers()
        elif s.path=='/real.zip': s.send_response(200); s.send_header('Content-Length',str(len(data))); s.end_headers(); s.wfile.write(data)
        elif s.path=='/page.html': s.send_response(200); s.end_headers(); s.wfile.write(b'<html>hi</html>')
        else: s.send_response(404); s.end_headers()
    def log_message(*a): pass
socketserver.TCPServer.allow_reuse_address=True
socketserver.TCPServer(('127.0.0.1',25700),H).serve_forever()
