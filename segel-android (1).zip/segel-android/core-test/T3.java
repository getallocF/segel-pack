import id.segel.pack.McProtocol;
public class T3 { public static void main(String[] a) throws Exception {
  McProtocol.BedrockStatus b = McProtocol.pingBedrock("127.0.0.1",19199,3000);
  System.out.println(b.edition+"|"+b.motd+"|"+b.protocol+"|"+b.version+"|"+b.online+"/"+b.max+"|"+b.level+"|"+b.gameMode);
  try { McProtocol.pingBedrock("127.0.0.1",19198,1000); } catch (Exception e) { System.out.println("EXPECTED "+e.getClass().getSimpleName()); }
}}
