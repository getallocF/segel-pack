import id.segel.pack.McProtocol;
public class T {
  public static void main(String[] a) throws Exception {
    int port = Integer.parseInt(System.getProperty("port", "25599"));
    int proto = Integer.parseInt(System.getProperty("proto", "767"));
    McProtocol.Status st = McProtocol.ping("127.0.0.1", port, 3000);
    System.out.println("PING " + st.version + " proto=" + st.protocol + " " + st.online + "/" + st.max + " motd=[" + st.motd + "]");
    McProtocol.Result r = McProtocol.fetchPackOffer("127.0.0.1", port, st.protocol, "SegelBot", 6, null);
    System.out.println("RESULT pack=" + (r.pack == null ? null : r.pack.url + " sha1=" + r.pack.sha1 + " forced=" + r.pack.forced + " uuid=" + r.pack.uuid) + " online=" + r.onlineMode + " msg=" + r.message);
  }
}
