import id.segel.pack.*;
import java.io.File;
public class T2 {
  public static void main(String[] a) throws Exception {
    File f = File.createTempFile("pack", ".zip");
    PackDownloader.Saved s = PackDownloader.download("http://127.0.0.1:25700/redir", f, (d,t)->{});
    System.out.println("OK bytes=" + s.bytes + " sha1=" + s.sha1 + " final=" + s.finalUrl);
    try { PackDownloader.download("http://127.0.0.1:25700/page.html", f, null); System.out.println("FAIL no error"); }
    catch (Exception e) { System.out.println("EXPECTED: " + e.getMessage()); }
    try { PackDownloader.download("http://127.0.0.1:25700/missing", f, null); System.out.println("FAIL no error"); }
    catch (Exception e) { System.out.println("EXPECTED: " + e.getMessage()); }
    java.lang.reflect.Method m = Class.forName("id.segel.pack.Srv").getMethod("parse", String.class);
    Object t = m.invoke(null, "{\"Answer\":[{\"name\":\"_minecraft._tcp.x.com\",\"type\":33,\"data\":\"0 5 25570 mc.x.com.\"}]}");
    System.out.println("SRV " + ((Srv.Target) t).host + ":" + ((Srv.Target) t).port);
  }
}
