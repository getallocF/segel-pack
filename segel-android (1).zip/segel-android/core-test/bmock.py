import socket,struct
M=bytes.fromhex("00ffff00fefefefefdfdfdfd12345678")
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.bind(('127.0.0.1',19199))
while True:
    d,a=s.recvfrom(100)
    if d[0]==1:
        t=d[1:9]; txt=b"MCPE;\xc2\xa7aDunia Segel;712;1.21.50;7;40;123456;Lobby;Survival;1;19132;19133"
        s.sendto(b"\x1c"+t+struct.pack(">q",42)+M+struct.pack(">H",len(txt))+txt,a)
