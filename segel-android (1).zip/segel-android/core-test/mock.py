import socket, struct, sys, zlib, threading, json, uuid, time
mode = sys.argv[1]; port = int(sys.argv[2]); proto = int(sys.argv[3])
def vi(n):
    out=b''
    while True:
        b=n&0x7f; n>>=7
        if n: out+=bytes([b|0x80])
        else: out+=bytes([b]); return out
def rvi(s):
    n=0;sh=0
    while True:
        b=s.recv(1)
        if not b: raise EOFError
        b=b[0]; n|=(b&0x7f)<<sh
        if not b&0x80: return n
        sh+=7
def rexact(s,n):
    d=b''
    while len(d)<n:
        c=s.recv(n-len(d))
        if not c: raise EOFError
        d+=c
    return d
def pstr(t): b=t.encode(); return vi(len(b))+b
comp=[-1]
def send(s,payload):
    if comp[0]>=0:
        if len(payload)<comp[0]: payload=vi(0)+payload
        else: payload=vi(len(payload))+zlib.compress(payload)
    s.sendall(vi(len(payload))+payload)
def recv(s):
    n=rvi(s); d=rexact(s,n)
    if comp[0]>=0:
        # strip data length
        i=0;sh=0;dl=0
        while True:
            b=d[i];i+=1;dl|=(b&0x7f)<<sh
            if not b&0x80:break
            sh+=7
        d=d[i:]
        if dl: d=zlib.decompress(d)
    return d
def handle(s):
    try:
        comp[0]=-1
        d=recv(s)  # handshake
        i=1
        # parse handshake: id, proto varint, str, port, state
        def rv(buf,i):
            n=0;sh=0
            while True:
                b=buf[i];i+=1;n|=(b&0x7f)<<sh
                if not b&0x80:return n,i
                sh+=7
        _,i=rv(d,0); cp,i=rv(d,i); l,i=rv(d,i); i+=l+2; state,i=rv(d,i)
        if state==1:
            recv(s)
            js=json.dumps({"version":{"name":"Mock 1.x","protocol":proto},"players":{"max":20,"online":3},"description":{"text":"§aMock §bServer"}})
            send(s,vi(0)+pstr(js))
            return
        ls=recv(s)
        if mode=='online':
            send(s,vi(1)+pstr("")+vi(4)+b'abcd'+vi(4)+b'1234'); return
        if mode=='kick':
            send(s,vi(0)+pstr(json.dumps({"text":"You are not whitelisted"}))); return
        send(s,vi(3)+vi(256)); comp[0]=256
        send(s,vi(2)+uuid.uuid4().bytes+pstr("SegelBot")+vi(0))
        url="https://example.com/packs/server-pack.zip"; h="a"*40
        if proto>=764:
            ack=recv(s); assert ack[0]==3, ack
            finish = 3 if proto>=766 else 2
            addid = 9 if proto>=766 else 7
            # junk packet + keepalive in config
            send(s,vi(1 if proto>=766 else 0)+pstr("minecraft:brand")+b'vanilla')
            if mode=='play':
                send(s,vi(finish))
                fa=recv(s); assert fa[0]==finish, fa
                send(s,vi(0x2b)+b'\x00'*1500)   # big junk play (compressed)
                time.sleep(0.5)
                send(s,vi(0x46)+uuid.UUID(int=7).bytes+pstr(url)+pstr(h)+b'\x01'+b'\x00')
            else:
                send(s,vi(addid)+uuid.UUID(int=7).bytes+pstr(url)+pstr(h)+b'\x01'+b'\x00')
        else:
            time.sleep(0.2)
            send(s,vi(0x4a)+pstr(url)+pstr(h))  # old style play
        time.sleep(1)
    except Exception as e:
        print("mock err",e,file=sys.stderr)
    finally:
        s.close()
srv=socket.socket(); srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); srv.bind(('127.0.0.1',port)); srv.listen(5)
while True:
    c,_=srv.accept(); threading.Thread(target=handle,args=(c,),daemon=True).start()
