import javax.tools.*;
import java.io.File;
import java.net.*;
import java.nio.file.*;
import java.util.*;
public class Compile {
  public static void main(String[] a) throws Exception {
    List<File> files = new ArrayList<>();
    for (String s : a[0].split(":")) Files.walk(Paths.get(s)).filter(p -> p.toString().endsWith(".java")).forEach(p -> files.add(p.toFile()));
    JavaCompiler c = ToolProvider.getSystemJavaCompiler();
    new File("out").mkdirs();
    StandardJavaFileManager fm = c.getStandardFileManager(null, null, null);
    boolean ok = c.getTask(null, fm, null, List.of("-d", "out", "-Xlint:all"), null, fm.getJavaFileObjectsFromFiles(files)).call();
    System.out.println(ok ? "COMPILE OK" : "COMPILE FAIL");
    if (!ok) System.exit(1);
    if (a.length > 1) {
      try (URLClassLoader l = new URLClassLoader(new URL[]{new File("out").toURI().toURL()})) {
        l.loadClass(a[1]).getMethod("main", String[].class).invoke(null, (Object) new String[0]);
      }
    }
  }
}
