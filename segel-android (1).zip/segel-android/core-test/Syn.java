import javax.tools.*;
import java.io.*;
import java.util.*;
public class Syn {
  public static void main(String[] a) throws Exception {
    JavaCompiler c = ToolProvider.getSystemJavaCompiler();
    StandardJavaFileManager fm = c.getStandardFileManager(null, null, null);
    DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
    List<File> fs = new ArrayList<>();
    for (String s : a) fs.add(new File(s));
    c.getTask(null, fm, d, List.of("-d", "out2", "-proc:none"), null, fm.getJavaFileObjectsFromFiles(fs)).call();
    int syntax=0;
    for (var x : d.getDiagnostics()) {
      String code = x.getCode();
      if (code.contains("cant.resolve") || code.contains("doesnt.exist") ) continue;
      syntax++;
      System.out.println(x.getKind()+" "+x.getSource().getName().replaceAll(".*/","")+":"+x.getLineNumber()+" "+x.getMessage(null));
    }
    System.out.println("non-symbol diagnostics: " + syntax);
  }
}
