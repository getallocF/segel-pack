# Panduan GitHub: dari zip jadi APK (bisa 100% dari HP)

Kamu butuh: akun GitHub (gratis) dan file `segel-android.zip`.
Tidak perlu PC, tidak perlu ekstrak zip. GitHub yang membuat APK-nya di cloud.

## A. Buat akun dan repo
1. Buka **github.com** di browser HP. Kalau tampilannya sempit, aktifkan "Situs desktop" di menu browser.
2. Daftar (Sign up) atau masuk (Sign in).
3. Tekan tanda **+** di kanan atas → **New repository**.
4. Repository name: `segel-pack`. Pilih **Public** (Actions gratis tanpa batas untuk repo publik).
5. Tekan **Create repository**.

## B. Unggah zip
1. Di halaman repo kosong, tekan **uploading an existing file**
   (atau **Add file → Upload files**).
2. Pilih `segel-android.zip` dari HP. **Jangan diekstrak.**
3. Tunggu selesai, tekan **Commit changes**.

## C. Buat workflow (satu file saja, diketik manual)
1. Tekan **Add file → Create new file**.
2. Di kolom nama file, ketik persis: `.github/workflows/build.yml`
   (saat mengetik `/`, GitHub otomatis membuat folder).
3. Tempel isi ini di editor:

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Ekstrak proyek
        run: unzip -q segel-android.zip

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - uses: android-actions/setup-android@v3

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.7

      - name: Build APK
        working-directory: segel-android
        run: gradle :app:assembleDebug --no-daemon

      - uses: actions/upload-artifact@v4
        with:
          name: SegelPack-apk
          path: segel-android/app/build/outputs/apk/debug/app-debug.apk
```

4. Tekan **Commit changes** → **Commit changes** lagi. Build langsung berjalan.

## D. Ambil APK
1. Buka tab **Actions** di repo.
2. Tekan run teratas bernama **Build APK**. Tunggu 4–6 menit sampai ada centang hijau.
3. Gulir ke bawah ke bagian **Artifacts** → tekan **SegelPack-apk** (perlu login).
4. File zip terunduh. Ekstrak lewat aplikasi File → di dalamnya ada `app-debug.apk`.

## E. Pasang di HP
1. Buka `app-debug.apk`.
2. Jika diminta, izinkan "Pasang aplikasi dari sumber ini" untuk aplikasi File/browser yang kamu pakai.
3. Tekan **Install**. Jika Play Protect memperingatkan, pilih "Install anyway"
   (APK ini ditandatangani kunci debug, bukan dari Play Store).

## Kalau build gagal (silang merah)
1. Actions → run yang merah → tekan job **build** → tekan langkah yang bertanda merah.
2. Salin 20–30 baris terakhir lognya dan kirim ke Claude. Biasanya satu perbaikan kecil.

## Memperbarui aplikasi nanti
Unggah ulang `segel-android.zip` baru dengan nama yang sama (Add file → Upload files → Commit).
Build otomatis jalan lagi dan menghasilkan APK baru.
