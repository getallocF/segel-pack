package id.segel.pack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/** Klien Minecraft Java minimal: ping status + login offline untuk menangkap paket resource pack. */
public final class McProtocol {

    public static final class Status {
        public int protocol;
        public String version = "";
        public String motd = "";
        public int online;
        public int max;
        public long latencyMs;
    }

    public static final class PackOffer {
        public String url = "";
        public String sha1 = "";
        public boolean forced;
        public String uuid = "";
    }

    public static final class Result {
        public PackOffer pack;          // null jika tidak ada
        public String message = "";     // alasan jika pack null
        public boolean onlineMode;      // server butuh akun premium
        public int protocolUsed;
        public String log = "";
    }

    public interface Progress { void say(String line); }

    // ---------- util byte ----------
    static void writeVarInt(OutputStream out, int value) throws IOException {
        while ((value & ~0x7F) != 0) {
            out.write((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.write(value);
    }

    static int readVarInt(InputStream in) throws IOException {
        int num = 0, shift = 0;
        for (int i = 0; i < 5; i++) {
            int b = in.read();
            if (b < 0) throw new EOFException("Koneksi ditutup server.");
            num |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return num;
            shift += 7;
        }
        throw new IOException("VarInt tidak valid.");
    }

    static void writeString(OutputStream out, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, b.length);
        out.write(b);
    }

    static String readString(DataInputStream in, int maxBytes) throws IOException {
        int len = readVarInt(in);
        if (len < 0 || len > maxBytes) throw new IOException("String tidak valid.");
        byte[] b = new byte[len];
        in.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }

    static byte[] frame(byte[] body) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        writeVarInt(o, body.length);
        o.write(body);
        return o.toByteArray();
    }

    static UUID offlineUuid(String name) throws Exception {
        byte[] h = MessageDigest.getInstance("MD5").digest(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        h[6] = (byte) ((h[6] & 0x0f) | 0x30);
        h[8] = (byte) ((h[8] & 0x3f) | 0x80);
        long msb = 0, lsb = 0;
        for (int i = 0; i < 8; i++) msb = (msb << 8) | (h[i] & 0xff);
        for (int i = 8; i < 16; i++) lsb = (lsb << 8) | (h[i] & 0xff);
        return new UUID(msb, lsb);
    }

    static byte[] handshake(String host, int port, int protocol, int nextState) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        writeVarInt(b, 0x00);
        writeVarInt(b, protocol);
        writeString(b, host);
        b.write((port >> 8) & 0xff);
        b.write(port & 0xff);
        writeVarInt(b, nextState);
        return frame(b.toByteArray());
    }

    // ---------- status ping ----------
    public static Status ping(String host, int port, int timeoutMs) throws Exception {
        long t0 = System.currentTimeMillis();
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            s.setSoTimeout(timeoutMs);
            OutputStream out = s.getOutputStream();
            out.write(handshake(host, port, 767, 1));
            out.write(new byte[]{0x01, 0x00});
            out.flush();
            DataInputStream in = new DataInputStream(s.getInputStream());
            int len = readVarInt(in);
            if (len < 2 || len > 2_000_000) throw new IOException("Jawaban server tidak valid.");
            byte[] pkt = new byte[len];
            in.readFully(pkt);
            DataInputStream p = new DataInputStream(new ByteArrayInputStream(pkt));
            if (readVarInt(p) != 0) throw new IOException("Server tidak mengirim status Java.");
            String json = readString(p, 2_000_000);
            Status st = new Status();
            st.latencyMs = System.currentTimeMillis() - t0;
            parseStatusJson(json, st);
            return st;
        }
    }

    /** Parser JSON status sederhana dengan org.json-independen agar bisa diuji tanpa Android. */
    static void parseStatusJson(String json, Status st) {
        st.version = firstString(json, "\"version\"", "\"name\"");
        st.protocol = (int) firstNumber(json, "\"version\"", "\"protocol\"");
        st.online = (int) firstNumber(json, "\"players\"", "\"online\"");
        st.max = (int) firstNumber(json, "\"players\"", "\"max\"");
        String d = firstString(json, "\"description\"", "\"text\"");
        if (d.isEmpty()) d = firstString(json, "", "\"description\"");
        st.motd = d.replaceAll("§.", "").trim();
    }

    private static int findKey(String json, String scope, String key) {
        int from = 0;
        if (!scope.isEmpty()) {
            from = json.indexOf(scope);
            if (from < 0) return -1;
        }
        int k = json.indexOf(key, from);
        if (k < 0) return -1;
        int colon = json.indexOf(':', k + key.length());
        return colon < 0 ? -1 : colon + 1;
    }

    private static String firstString(String json, String scope, String key) {
        int i = findKey(json, scope, key);
        if (i < 0) return "";
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        if (i >= json.length() || json.charAt(i) != '"') return "";
        StringBuilder sb = new StringBuilder();
        for (i = i + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                char n = json.charAt(++i);
                if (n == 'u' && i + 4 < json.length()) {
                    sb.append((char) Integer.parseInt(json.substring(i + 1, i + 5), 16));
                    i += 4;
                } else if (n == 'n') sb.append(' ');
                else sb.append(n);
            } else if (c == '"') break;
            else sb.append(c);
        }
        return sb.toString();
    }

    private static long firstNumber(String json, String scope, String key) {
        int i = findKey(json, scope, key);
        if (i < 0) return 0;
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        int j = i;
        while (j < json.length() && (Character.isDigit(json.charAt(j)) || json.charAt(j) == '-')) j++;
        try { return Long.parseLong(json.substring(i, j)); } catch (Exception e) { return 0; }
    }


    // ---------- Bedrock status (RakNet unconnected ping, UDP) ----------
    public static final class BedrockStatus {
        public String edition = "";
        public String motd = "";
        public int protocol;
        public String version = "";
        public int online;
        public int max;
        public String level = "";
        public String gameMode = "";
        public long latencyMs;
    }

    private static final byte[] RAKNET_MAGIC = {
        0x00, (byte) 0xff, (byte) 0xff, 0x00, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe,
        (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, 0x12, 0x34, 0x56, 0x78
    };

    public static BedrockStatus pingBedrock(String host, int port, int timeoutMs) throws Exception {
        long t0 = System.currentTimeMillis();
        java.net.DatagramSocket sock = new java.net.DatagramSocket();
        try {
            sock.setSoTimeout(timeoutMs);
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(33);
            bb.put((byte) 0x01);
            bb.putLong(t0);
            bb.put(RAKNET_MAGIC);
            bb.putLong(0x5365676c5061636bL);
            byte[] data = bb.array();
            java.net.InetAddress addr = java.net.InetAddress.getByName(host);
            sock.send(new java.net.DatagramPacket(data, data.length, addr, port));
            byte[] buf = new byte[2048];
            java.net.DatagramPacket rp = new java.net.DatagramPacket(buf, buf.length);
            sock.receive(rp);
            return parseBedrockPong(buf, rp.getLength(), System.currentTimeMillis() - t0);
        } finally {
            sock.close();
        }
    }

    static BedrockStatus parseBedrockPong(byte[] buf, int length, long latency) throws IOException {
        if (length < 35 || buf[0] != 0x1c) throw new IOException("Server tidak menjawab sebagai Bedrock.");
        int len = ((buf[33] & 0xff) << 8) | (buf[34] & 0xff);
        if (35 + len > length) throw new IOException("Jawaban Bedrock terputus.");
        String[] p = new String(buf, 35, len, StandardCharsets.UTF_8).split(";", -1);
        BedrockStatus st = new BedrockStatus();
        st.latencyMs = latency;
        st.edition = p.length > 0 ? p[0] : "";
        st.motd = p.length > 1 ? p[1].replaceAll("§.", "").trim() : "";
        st.protocol = p.length > 2 ? toInt(p[2]) : 0;
        st.version = p.length > 3 ? p[3] : "";
        st.online = p.length > 4 ? toInt(p[4]) : 0;
        st.max = p.length > 5 ? toInt(p[5]) : 0;
        st.level = p.length > 7 ? p[7].replaceAll("§.", "").trim() : "";
        st.gameMode = p.length > 8 ? p[8] : "";
        return st;
    }

    private static int toInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    // ---------- login + tangkap resource pack ----------
    public static Result fetchPackOffer(String host, int port, int protocol, String playerName,
                                        int waitSeconds, Progress progress) {
        Result res = new Result();
        res.protocolUsed = protocol;
        StringBuilder log = new StringBuilder();
        Progress say = line -> { log.append(line).append('\n'); if (progress != null) progress.say(line); };
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), 8000);
            s.setSoTimeout(4000);
            s.setTcpNoDelay(true);
            OutputStream out = s.getOutputStream();
            DataInputStream in = new DataInputStream(s.getInputStream());

            out.write(handshake(host, port, protocol, 2));
            ByteArrayOutputStream ls = new ByteArrayOutputStream();
            writeVarInt(ls, 0x00);
            writeString(ls, playerName);
            if (protocol >= 764) {                       // 1.20.2+
                UUID u = offlineUuid(playerName);
                writeUuid(ls, u);
            } else if (protocol >= 761) {                // 1.19.3 - 1.20.1
                ls.write(1);
                writeUuid(ls, offlineUuid(playerName));
            } else if (protocol == 760) {                // 1.19.1/1.19.2
                ls.write(0);
                ls.write(1);
                writeUuid(ls, offlineUuid(playerName));
            } else if (protocol == 759) {                // 1.19
                ls.write(0);
            }
            out.write(frame(ls.toByteArray()));
            out.flush();
            say.say("Masuk sebagai " + playerName + " (protokol " + protocol + ")…");

            int threshold = -1;
            boolean inLoginState = true;
            boolean config = false;
            long deadline = System.currentTimeMillis() + waitSeconds * 1000L;
            int packets = 0;

            while (System.currentTimeMillis() < deadline) {
                byte[] payload;
                try {
                    payload = readPacket(in, threshold);
                } catch (java.net.SocketTimeoutException e) {
                    continue;
                }
                packets++;
                DataInputStream p = new DataInputStream(new ByteArrayInputStream(payload));
                int id = readVarInt(p);
                byte[] body = new byte[payload.length - varIntLen(id)];
                System.arraycopy(payload, varIntLen(id), body, 0, body.length);

                if (inLoginState) {
                    if (id == 0x00) {
                        String reason = readString(new DataInputStream(new ByteArrayInputStream(body)), 100000);
                        res.message = "Server menolak: " + cleanJsonText(reason);
                        say.say(res.message);
                        break;
                    } else if (id == 0x01) {
                        res.onlineMode = true;
                        res.message = "Server memakai online-mode (wajib akun Minecraft premium). "
                                + "Aplikasi ini tidak login ke akun, jadi tidak bisa masuk.";
                        say.say(res.message);
                        break;
                    } else if (id == 0x03) {
                        threshold = readVarInt(new ByteArrayInputStream(body));
                        say.say("Kompresi aktif (batas " + threshold + ").");
                    } else if (id == 0x04) {              // login plugin request -> jawab "tidak mengerti"
                        ByteArrayInputStream bb = new ByteArrayInputStream(body);
                        int msgId = readVarInt(bb);
                        ByteArrayOutputStream r = new ByteArrayOutputStream();
                        writeVarInt(r, 0x02);
                        writeVarInt(r, msgId);
                        r.write(0);
                        out.write(frameMaybeCompressed(r.toByteArray(), threshold));
                        out.flush();
                    } else if (id == 0x02) {
                        say.say("Login berhasil.");
                        inLoginState = false;
                        if (protocol >= 764) {
                            ByteArrayOutputStream r = new ByteArrayOutputStream();
                            writeVarInt(r, 0x03);          // Login Acknowledged
                            out.write(frameMaybeCompressed(r.toByteArray(), threshold));
                            out.flush();
                            config = true;
                        }
                    }
                    continue;
                }

                // Setelah login: cari paket resource pack berdasarkan ISI, bukan ID (ID beda tiap versi).
                PackOffer offer = sniffPackOffer(body);
                if (offer != null) {
                    res.pack = offer;
                    say.say("Paket resource pack diterima.");
                    break;
                }
                if (config) {
                    // Finish Configuration: id 0x02 (1.20.2-1.20.4) / 0x03 (1.20.5+), tanpa isi.
                    int finishId = protocol >= 766 ? 0x03 : 0x02;
                    int ackId = finishId;
                    if (id == finishId && body.length == 0) {
                        ByteArrayOutputStream r = new ByteArrayOutputStream();
                        writeVarInt(r, ackId);
                        out.write(frameMaybeCompressed(r.toByteArray(), threshold));
                        out.flush();
                        config = false;
                        say.say("Konfigurasi selesai, menunggu server mengirim pack…");
                    } else {
                        // keep alive config: 8 byte long
                        int kaIn = protocol >= 766 ? 0x04 : 0x03;
                        int kaOut = protocol >= 766 ? 0x04 : 0x03;
                        if (id == kaIn && body.length == 8) {
                            ByteArrayOutputStream r = new ByteArrayOutputStream();
                            writeVarInt(r, kaOut);
                            r.write(body);
                            out.write(frameMaybeCompressed(r.toByteArray(), threshold));
                            out.flush();
                        }
                        // ping config
                        int pingIn = protocol >= 766 ? 0x05 : 0x04;
                        if (id == pingIn && body.length == 4) {
                            ByteArrayOutputStream r = new ByteArrayOutputStream();
                            writeVarInt(r, protocol >= 766 ? 0x05 : 0x04);
                            r.write(body);
                            out.write(frameMaybeCompressed(r.toByteArray(), threshold));
                            out.flush();
                        }
                    }
                }
            }
            if (res.pack == null && res.message.isEmpty()) {
                res.message = "Server tidak mengirim resource pack dalam " + waitSeconds
                        + " detik (" + packets + " paket diterima). Mungkin server memang tidak memakai pack.";
            }
        } catch (java.net.SocketTimeoutException e) {
            res.message = "Server tidak menjawab (timeout).";
        } catch (java.net.ConnectException e) {
            res.message = "Koneksi ditolak. Cek IP dan port.";
        } catch (java.net.UnknownHostException e) {
            res.message = "Nama host tidak ditemukan.";
        } catch (EOFException e) {
            res.message = res.pack != null ? "" : "Server memutus koneksi (mungkin whitelist atau versi tidak cocok).";
        } catch (Exception e) {
            res.message = "Gagal: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
        res.log = log.toString();
        return res;
    }

    private static void writeUuid(OutputStream o, UUID u) throws IOException {
        DataOutputStream d = new DataOutputStream(o);
        d.writeLong(u.getMostSignificantBits());
        d.writeLong(u.getLeastSignificantBits());
    }

    static int varIntLen(int v) {
        int n = 1;
        while ((v & ~0x7F) != 0) { v >>>= 7; n++; }
        return n;
    }

    static byte[] frameMaybeCompressed(byte[] payload, int threshold) throws IOException {
        if (threshold < 0) return frame(payload);
        ByteArrayOutputStream inner = new ByteArrayOutputStream();
        if (payload.length < threshold) {
            writeVarInt(inner, 0);
            inner.write(payload);
        } else {
            java.util.zip.Deflater d = new java.util.zip.Deflater();
            d.setInput(payload);
            d.finish();
            ByteArrayOutputStream z = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            while (!d.finished()) z.write(buf, 0, d.deflate(buf));
            d.end();
            writeVarInt(inner, payload.length);
            inner.write(z.toByteArray());
        }
        return frame(inner.toByteArray());
    }

    static byte[] readPacket(DataInputStream in, int threshold) throws IOException {
        int len = readVarInt(in);
        if (len < 0 || len > 8_000_000) throw new IOException("Paket terlalu besar.");
        byte[] raw = new byte[len];
        in.readFully(raw);
        if (threshold < 0) return raw;
        ByteArrayInputStream bi = new ByteArrayInputStream(raw);
        int dataLen = readVarInt(bi);
        int used = varIntLen(dataLen);
        byte[] rest = new byte[raw.length - used];
        System.arraycopy(raw, used, rest, 0, rest.length);
        if (dataLen == 0) return rest;
        if (dataLen > 16_000_000) throw new IOException("Paket terlalu besar.");
        Inflater inf = new Inflater();
        inf.setInput(rest);
        byte[] outb = new byte[dataLen];
        try {
            int got = 0;
            while (got < dataLen && !inf.finished()) {
                int n = inf.inflate(outb, got, dataLen - got);
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                got += n;
            }
        } catch (DataFormatException e) {
            throw new IOException("Paket terkompresi rusak.");
        } finally {
            inf.end();
        }
        return outb;
    }

    // ---------- deteksi paket resource pack dari isi ----------
    /** Bentuk 1 (1.20.3+): UUID(16) + url + hash(40) + forced(+prompt). Bentuk 2 (lama): url + hash + forced(+prompt). */
    static PackOffer sniffPackOffer(byte[] body) {
        if (body.length < 8 || body.length > 20000) return null;
        PackOffer a = tryParse(body, 16);
        if (a != null) return a;
        return tryParse(body, 0);
    }

    private static PackOffer tryParse(byte[] body, int offset) {
        try {
            if (body.length < offset + 3) return null;
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(body, offset, body.length - offset));
            String url = readString(in, 32767);
            if (!(url.startsWith("http://") || url.startsWith("https://") || url.startsWith("level://"))) return null;
            String hash = readString(in, 64);
            if (hash.length() != 0 && hash.length() != 40) return null;
            if (!hash.matches("[0-9a-fA-F]*")) return null;
            PackOffer o = new PackOffer();
            o.url = url;
            o.sha1 = hash.toLowerCase();
            int f = in.read();
            o.forced = f == 1;
            if (offset == 16) {
                java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(body, 0, 16);
                o.uuid = new UUID(bb.getLong(), bb.getLong()).toString();
            }
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    static String cleanJsonText(String json) {
        String t = firstString(json, "", "\"text\"");
        if (t.isEmpty()) t = firstString(json, "", "\"translate\"");
        if (t.isEmpty()) t = json;
        return t.replaceAll("§.", "").trim();
    }
}
