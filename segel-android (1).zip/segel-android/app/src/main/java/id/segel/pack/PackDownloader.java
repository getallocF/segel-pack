package id.segel.pack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/** Mengunduh file pack lewat HTTP(S), mengikuti pengalihan, memeriksa isi zip dan SHA-1. */
public final class PackDownloader {

    public interface Progress { void update(long done, long total); }

    public static final class Saved {
        public long bytes;
        public String sha1 = "";
        public String finalUrl = "";
    }

    public static final long MAX_BYTES = 256L * 1024 * 1024;

    public static Saved download(String startUrl, File dest, Progress progress) throws IOException {
        String current = startUrl;
        HttpURLConnection conn = null;
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(current);
            String proto = u.getProtocol();
            if (!proto.equals("http") && !proto.equals("https")) {
                throw new IOException("Hanya tautan http atau https yang bisa diunduh.");
            }
            conn = (HttpURLConnection) u.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent", "SegelPack/1.0");
            conn.setRequestProperty("Accept", "application/zip,application/octet-stream,*/*");
            int code = conn.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = conn.getHeaderField("Location");
                conn.disconnect();
                if (loc == null) throw new IOException("Pengalihan tanpa tujuan.");
                current = new URL(u, loc).toString();
                conn = null;
                continue;
            }
            if (code < 200 || code >= 300) {
                conn.disconnect();
                throw new IOException("Server pack menjawab HTTP " + code + ".");
            }
            break;
        }
        if (conn == null) throw new IOException("Terlalu banyak pengalihan.");

        long total = conn.getContentLengthLong();
        if (total > MAX_BYTES) throw new IOException("Pack lebih besar dari 256 MB.");
        MessageDigest md;
        try { md = MessageDigest.getInstance("SHA-1"); } catch (Exception e) { throw new IOException(e); }
        long done = 0;
        byte[] first = new byte[4];
        int firstLen = 0;
        try (InputStream in = conn.getInputStream(); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[32 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                if (done == 0) {
                    firstLen = Math.min(4, n);
                    System.arraycopy(buf, 0, first, 0, firstLen);
                }
                done += n;
                if (done > MAX_BYTES) throw new IOException("Pack lebih besar dari 256 MB.");
                md.update(buf, 0, n);
                out.write(buf, 0, n);
                if (progress != null) progress.update(done, total);
            }
        } finally {
            conn.disconnect();
        }
        boolean zip = firstLen >= 4 && first[0] == 0x50 && first[1] == 0x4b
                && (first[2] == 0x03 || first[2] == 0x05 || first[2] == 0x07);
        if (!zip) {
            //noinspection ResultOfMethodCallIgnored
            dest.delete();
            throw new IOException("Berkas di tautan itu bukan zip. Mungkin halaman web atau akses ditolak.");
        }
        Saved s = new Saved();
        s.bytes = done;
        s.finalUrl = current;
        StringBuilder hex = new StringBuilder();
        for (byte b : md.digest()) hex.append(String.format("%02x", b));
        s.sha1 = hex.toString();
        return s;
    }
}
