package id.segel.pack;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#0E1311");
    private static final int CARD = Color.parseColor("#17201C");
    private static final int LINE = Color.parseColor("#2A3731");
    private static final int TEXT = Color.parseColor("#E8F0EB");
    private static final int MUTED = Color.parseColor("#8FA399");
    private static final int ACCENT = Color.parseColor("#4ADE80");
    private static final int DANGER = Color.parseColor("#F87171");

    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    private LinearLayout serverTab;
    private LinearLayout githubTab;
    private Button tabServerBtn;
    private Button tabGithubBtn;

    // server tab
    private EditText hostInput;
    private EditText portInput;
    private EditText nameInput;
    private Button pingBtn;
    private Button fetchBtn;
    private Button edJava;
    private Button edBedrock;
    private boolean bedrock = false;
    private TextView statusView;
    private LinearLayout resultBox;

    // github tab
    private EditText queryInput;
    private TextView ghStatus;
    private LinearLayout ghResults;
    private String ghSort = "stars";

    private McProtocol.PackOffer lastOffer;
    private String lastHost = "";

    // ------------------------------------------------------------ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(12), dp(16), 0);

        TextView title = text("Segel Pack", 26, TEXT, true);
        root.addView(title);
        TextView sub = text("Ambil resource pack server Java dan cari tools di GitHub.", 13, MUTED, false);
        sub.setPadding(0, dp(2), 0, dp(12));
        root.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabServerBtn = tabButton("Server");
        tabGithubBtn = tabButton("GitHub");
        tabs.addView(tabServerBtn, new LinearLayout.LayoutParams(0, dp(44), 1));
        tabs.addView(tabGithubBtn, new LinearLayout.LayoutParams(0, dp(44), 1));
        root.addView(tabs);

        serverTab = buildServerTab();
        githubTab = buildGithubTab();
        root.addView(serverTab, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(githubTab, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        tabServerBtn.setOnClickListener(v -> showTab(true));
        tabGithubBtn.setOnClickListener(v -> showTab(false));
        showTab(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }

    private void showTab(boolean server) {
        serverTab.setVisibility(server ? View.VISIBLE : View.GONE);
        githubTab.setVisibility(server ? View.GONE : View.VISIBLE);
        styleTab(tabServerBtn, server);
        styleTab(tabGithubBtn, !server);
    }

    // ------------------------------------------------------------ server tab
    private LinearLayout buildServerTab() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(14), 0, dp(24));
        sv.addView(col);
        wrap.addView(sv, new LinearLayout.LayoutParams(-1, -1));

        col.addView(label("Edisi"));
        LinearLayout edRow = new LinearLayout(this);
        edRow.setOrientation(LinearLayout.HORIZONTAL);
        edJava = chip("Java");
        edBedrock = chip("Bedrock");
        edRow.addView(edJava);
        edRow.addView(edBedrock);
        col.addView(edRow);
        col.addView(label("Alamat server"));
        hostInput = input("play.example.com atau 192.168.1.5", InputType.TYPE_TEXT_VARIATION_URI);
        col.addView(hostInput);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout pCol = new LinearLayout(this);
        pCol.setOrientation(LinearLayout.VERTICAL);
        pCol.addView(label("Port"));
        portInput = input("25565", InputType.TYPE_CLASS_NUMBER);
        portInput.setText("25565");
        pCol.addView(portInput);
        LinearLayout nCol = new LinearLayout(this);
        nCol.setOrientation(LinearLayout.VERTICAL);
        nCol.addView(label("Nama pemain"));
        nameInput = input("SegelPack", InputType.TYPE_CLASS_TEXT);
        nameInput.setText("SegelPack");
        nCol.addView(nameInput);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, -2, 1);
        lp1.rightMargin = dp(10);
        row.addView(pCol, lp1);
        row.addView(nCol, new LinearLayout.LayoutParams(0, -2, 1.4f));
        col.addView(row);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, dp(14), 0, 0);
        pingBtn = button("Cek server", false);
        fetchBtn = button("Ambil pack", true);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, dp(48), 1);
        b1.rightMargin = dp(10);
        btns.addView(pingBtn, b1);
        btns.addView(fetchBtn, new LinearLayout.LayoutParams(0, dp(48), 1));
        col.addView(btns);

        statusView = text("", 14, MUTED, false);
        statusView.setPadding(0, dp(14), 0, 0);
        statusView.setTextIsSelectable(true);
        col.addView(statusView);

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(resultBox);

        TextView note = text("Cara kerja: aplikasi masuk ke server seperti pemain biasa, lalu menangkap "
                + "tautan resource pack yang server kirim. Hanya berfungsi di server Java yang tidak "
                + "mewajibkan akun premium (online-mode mati) dan yang memang mengirim pack. "
                + "Pakai untuk pack milikmu atau yang diizinkan pemiliknya.", 12, MUTED, false);
        note.setPadding(0, dp(22), 0, 0);
        col.addView(note);

        edJava.setOnClickListener(v -> setEdition(false));
        edBedrock.setOnClickListener(v -> setEdition(true));
        setEdition(false);
        pingBtn.setOnClickListener(v -> doPing());
        fetchBtn.setOnClickListener(v -> doFetch());
        return wrap;
    }

    private String[] resolveHostPort() {
        String host = hostInput.getText().toString().trim();
        String port = portInput.getText().toString().trim();
        host = host.replaceFirst("^[a-zA-Z]+://", "");
        int slash = host.indexOf('/');
        if (slash >= 0) host = host.substring(0, slash);
        int colon = host.lastIndexOf(':');
        if (colon > 0 && host.indexOf(':') == colon && host.substring(colon + 1).matches("\\d{1,5}")) {
            port = host.substring(colon + 1);
            host = host.substring(0, colon);
            portInput.setText(port);
            hostInput.setText(host);
        }
        if (host.isEmpty()) return null;
        if (port.isEmpty()) port = "25565";
        return new String[]{host, port};
    }

    private void setEdition(boolean b) {
        bedrock = b;
        styleChip(edJava, !b);
        styleChip(edBedrock, b);
        String cur = portInput.getText().toString().trim();
        if (b && (cur.isEmpty() || cur.equals("25565"))) portInput.setText("19132");
        if (!b && (cur.isEmpty() || cur.equals("19132"))) portInput.setText("25565");
        fetchBtn.setText(b ? "Info pack" : "Ambil pack");
        resultBox.removeAllViews();
        setStatus("", false);
    }

    private String describeBedrock(McProtocol.BedrockStatus st) {
        StringBuilder sb = new StringBuilder();
        sb.append(st.motd.isEmpty() ? "Server Bedrock" : st.motd).append('\n');
        sb.append(st.edition).append(' ').append(st.version).append(" · protokol ").append(st.protocol).append('\n');
        sb.append("Pemain ").append(st.online).append('/').append(st.max)
                .append(" · ").append(st.latencyMs).append(" ms");
        if (!st.level.isEmpty() || !st.gameMode.isEmpty()) {
            sb.append('\n').append(st.gameMode).append(st.level.isEmpty() ? "" : " · " + st.level);
        }
        return sb.toString();
    }

    private static final String BEDROCK_NOTE =
            "Pengambilan pack dari server Bedrock belum didukung. Bedrock mengirim pack lewat protokol "
            + "RakNet yang butuh login Xbox, dan pack server umumnya terenkripsi dan dilindungi pembuatnya. "
            + "Kalau itu pack milikmu, ambil file aslinya dari sumbernya.";

    private void doPing() {
        final String[] hp = resolveHostPort();
        if (hp == null) { setStatus("Isi alamat server dulu.", true); return; }
        final int port;
        try { port = Integer.parseInt(hp[1]); } catch (NumberFormatException e) { setStatus("Port tidak valid.", true); return; }
        if (port < 1 || port > 65535) { setStatus("Port harus 1 sampai 65535.", true); return; }
        hideKeyboard();
        busy(true);
        resultBox.removeAllViews();
        setStatus("Menghubungi server…", false);
        pool.execute(() -> {
            try {
                if (bedrock) {
                    final String bm = describeBedrock(McProtocol.pingBedrock(hp[0], port, 5000));
                    runOnUiThread(() -> { setStatus(bm, false); busy(false); });
                    return;
                }
                Srv.Target t = port == 25565 ? Srv.lookup(hp[0]) : null;
                String h = t != null ? t.host : hp[0];
                int p = t != null ? t.port : port;
                McProtocol.Status st = McProtocol.ping(h, p, 6000);
                final String msg = describe(st, t);
                runOnUiThread(() -> { setStatus(msg, false); busy(false); });
            } catch (Exception e) {
                final String m = friendly(e);
                runOnUiThread(() -> { setStatus(m, true); busy(false); });
            }
        });
    }

    private String describe(McProtocol.Status st, Srv.Target t) {
        StringBuilder sb = new StringBuilder();
        sb.append(st.motd.isEmpty() ? "Server Java" : st.motd).append('\n');
        sb.append(st.version).append(" · protokol ").append(st.protocol).append('\n');
        sb.append("Pemain ").append(st.online).append('/').append(st.max)
                .append(" · ").append(st.latencyMs).append(" ms");
        if (t != null) sb.append("\nLewat SRV ").append(t.host).append(':').append(t.port);
        return sb.toString();
    }

    private void doFetch() {
        final String[] hp = resolveHostPort();
        if (hp == null) { setStatus("Isi alamat server dulu.", true); return; }
        final int port;
        try { port = Integer.parseInt(hp[1]); } catch (NumberFormatException e) { setStatus("Port tidak valid.", true); return; }
        if (port < 1 || port > 65535) { setStatus("Port harus 1 sampai 65535.", true); return; }
        String nm = nameInput.getText().toString().trim().replaceAll("[^A-Za-z0-9_]", "");
        if (nm.length() < 3) nm = "SegelPack";
        if (nm.length() > 16) nm = nm.substring(0, 16);
        final String name = nm;
        hideKeyboard();
        busy(true);
        resultBox.removeAllViews();
        lastOffer = null;
        setStatus("Menghubungi server…", false);
        pool.execute(() -> {
            try {
                if (bedrock) {
                    final String bm = describeBedrock(McProtocol.pingBedrock(hp[0], port, 5000));
                    runOnUiThread(() -> { busy(false); setStatus(bm + "\n\n" + BEDROCK_NOTE, false); });
                    return;
                }
                Srv.Target t = port == 25565 ? Srv.lookup(hp[0]) : null;
                final String h = t != null ? t.host : hp[0];
                final int p = t != null ? t.port : port;
                McProtocol.Status st = McProtocol.ping(h, p, 6000);
                final String head = describe(st, t);
                runOnUiThread(() -> setStatus(head + "\n\nMasuk dan menunggu pack…", false));
                McProtocol.Result r = McProtocol.fetchPackOffer(h, p, st.protocol, name, 25, null);
                runOnUiThread(() -> {
                    busy(false);
                    if (r.pack != null) {
                        lastOffer = r.pack;
                        lastHost = hp[0];
                        setStatus(head + "\n\nPack ditemukan.", false);
                        showOffer(r.pack);
                    } else {
                        setStatus(head + "\n\n" + (r.message.isEmpty() ? "Pack tidak ditemukan." : r.message), true);
                    }
                });
            } catch (Exception e) {
                final String m = friendly(e);
                runOnUiThread(() -> { busy(false); setStatus(m, true); });
            }
        });
    }

    private void showOffer(final McProtocol.PackOffer o) {
        resultBox.removeAllViews();
        LinearLayout card = card();
        card.addView(text("Resource pack", 12, MUTED, false));
        TextView url = text(o.url, 14, TEXT, false);
        url.setTypeface(Typeface.MONOSPACE);
        url.setTextIsSelectable(true);
        url.setPadding(0, dp(4), 0, dp(8));
        card.addView(url);
        String info = (o.sha1.isEmpty() ? "SHA-1 tidak diberikan" : "SHA-1 " + o.sha1)
                + (o.forced ? "\nServer mewajibkan pack ini." : "");
        TextView meta = text(info, 12, MUTED, false);
        meta.setTypeface(Typeface.MONOSPACE);
        meta.setTextIsSelectable(true);
        card.addView(meta);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(14), 0, 0);
        Button dl = button("Unduh", true);
        Button cp = button("Salin", false);
        Button sh = button("Bagikan", false);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(46), 1.2f);
        a.rightMargin = dp(8);
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0, dp(46), 1);
        c.rightMargin = dp(8);
        row.addView(dl, a);
        row.addView(cp, c);
        row.addView(sh, new LinearLayout.LayoutParams(0, dp(46), 1));
        card.addView(row);
        resultBox.addView(card);

        dl.setOnClickListener(v -> startDownload(o));
        cp.setOnClickListener(v -> copy(o.url));
        sh.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, o.url);
            startActivity(Intent.createChooser(i, "Bagikan tautan pack"));
        });
    }

    private void startDownload(final McProtocol.PackOffer o) {
        if (o.url.startsWith("level://")) {
            setStatus("Pack ini bawaan dunia server (level://), tidak ada tautan untuk diunduh.", true);
            return;
        }
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
            setStatus("Izinkan akses penyimpanan, lalu tekan Unduh lagi.", false);
            return;
        }
        busy(true);
        final TextView progress = text("Mengunduh…", 13, MUTED, false);
        progress.setPadding(0, dp(10), 0, 0);
        resultBox.addView(progress);
        final String fname = safeName(lastHost) + (o.sha1.length() >= 8 ? "-" + o.sha1.substring(0, 8) : "") + ".zip";
        pool.execute(() -> {
            File tmp = new File(getCacheDir(), "pack-download.tmp");
            try {
                final long[] last = {0};
                PackDownloader.Saved s = PackDownloader.download(o.url, tmp, (got, total) -> {
                    long now = System.currentTimeMillis();
                    if (now - last[0] < 250) return;
                    last[0] = now;
                    final String t = total > 0
                            ? "Mengunduh… " + mb(got) + " / " + mb(total)
                            : "Mengunduh… " + mb(got);
                    runOnUiThread(() -> progress.setText(t));
                });
                String verdict;
                if (o.sha1.isEmpty()) verdict = "SHA-1 server kosong, tidak diverifikasi.";
                else if (o.sha1.equalsIgnoreCase(s.sha1)) verdict = "SHA-1 cocok dengan yang dikirim server.";
                else verdict = "SHA-1 berbeda dari yang dikirim server (" + s.sha1.substring(0, 8) + "…). "
                        + "Isi pack mungkin berubah sejak dikirim.";
                String where = saveToDownloads(tmp, fname);
                final String done = "Tersimpan: " + where + "\n" + mb(s.bytes) + " · " + verdict;
                runOnUiThread(() -> { progress.setText(done); progress.setTextColor(ACCENT); busy(false); });
            } catch (Exception e) {
                final String m = friendly(e);
                runOnUiThread(() -> { progress.setText(m); progress.setTextColor(DANGER); busy(false); });
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        });
    }

    private String saveToDownloads(File src, String name) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SegelPack");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("Tidak bisa membuat berkas di folder Download.");
            try (InputStream in = new FileInputStream(src); OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("Tidak bisa menulis ke folder Download.");
                copyStream(in, out);
            }
            return "Download/SegelPack/" + name;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SegelPack");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Tidak bisa membuat folder Download/SegelPack.");
        File dest = new File(dir, name);
        try (InputStream in = new FileInputStream(src); OutputStream out = new java.io.FileOutputStream(dest)) {
            copyStream(in, out);
        }
        return "Download/SegelPack/" + name;
    }

    private static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }

    // ------------------------------------------------------------ github tab
    private LinearLayout buildGithubTab() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(14), 0, 0);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        queryInput = input("cari tools, mis. minecraft resource pack", InputType.TYPE_CLASS_TEXT);
        queryInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        queryInput.setSingleLine(true);
        Button go = button("Cari", true);
        LinearLayout.LayoutParams q = new LinearLayout.LayoutParams(0, -2, 1);
        q.rightMargin = dp(8);
        row.addView(queryInput, q);
        row.addView(go, new LinearLayout.LayoutParams(dp(80), dp(48)));
        wrap.addView(row);

        HorizontalScrollView chips = new HorizontalScrollView(this);
        chips.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(0, dp(10), 0, dp(6));
        String[][] presets = {
                {"Resource pack", "minecraft resource pack tool"},
                {"Pack extractor", "minecraft resource pack extractor"},
                {"Server pack", "minecraft server resource pack"},
                {"Bedrock", "minecraft bedrock resource pack tool"},
                {"Texture", "minecraft texture pack converter"},
        };
        for (final String[] p : presets) {
            Button chip = chip(p[0]);
            chip.setOnClickListener(v -> { queryInput.setText(p[1]); searchGithub(); });
            chipRow.addView(chip);
        }
        chips.addView(chipRow);
        wrap.addView(chips);

        LinearLayout sortRow = new LinearLayout(this);
        sortRow.setOrientation(LinearLayout.HORIZONTAL);
        final Button sStars = chip("★ Terpopuler");
        final Button sNew = chip("Terbaru");
        sortRow.addView(sStars);
        sortRow.addView(sNew);
        wrap.addView(sortRow);
        styleChip(sStars, true);
        styleChip(sNew, false);
        sStars.setOnClickListener(v -> { ghSort = "stars"; styleChip(sStars, true); styleChip(sNew, false); searchGithub(); });
        sNew.setOnClickListener(v -> { ghSort = "updated"; styleChip(sStars, false); styleChip(sNew, true); searchGithub(); });

        ghStatus = text("Pilih kategori di atas atau ketik kata kunci.", 13, MUTED, false);
        ghStatus.setPadding(0, dp(8), 0, dp(6));
        wrap.addView(ghStatus);

        ScrollView sv = new ScrollView(this);
        ghResults = new LinearLayout(this);
        ghResults.setOrientation(LinearLayout.VERTICAL);
        ghResults.setPadding(0, 0, 0, dp(24));
        sv.addView(ghResults);
        wrap.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        go.setOnClickListener(v -> searchGithub());
        queryInput.setOnEditorActionListener((tv, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH) { searchGithub(); return true; }
            return false;
        });
        return wrap;
    }

    private void searchGithub() {
        final String q = queryInput.getText().toString().trim();
        if (q.isEmpty()) { ghStatus.setText("Ketik kata kunci dulu."); ghStatus.setTextColor(DANGER); return; }
        hideKeyboard();
        ghStatus.setText("Mencari di GitHub…");
        ghStatus.setTextColor(MUTED);
        ghResults.removeAllViews();
        final String sort = ghSort;
        pool.execute(() -> {
            try {
                final List<GitHub.Repo> repos = GitHub.search(q, sort);
                runOnUiThread(() -> {
                    ghStatus.setTextColor(MUTED);
                    ghStatus.setText(repos.isEmpty() ? "Tidak ada hasil." : repos.size() + " repo");
                    for (GitHub.Repo r : repos) ghResults.addView(repoRow(r));
                });
            } catch (Exception e) {
                final String m = e.getMessage() == null ? "Pencarian gagal." : e.getMessage();
                runOnUiThread(() -> { ghStatus.setText(friendly(new IOException(m))); ghStatus.setTextColor(DANGER); });
            }
        });
    }

    private View repoRow(final GitHub.Repo r) {
        LinearLayout card = card();
        card.addView(text(r.fullName, 15, ACCENT, true));
        if (!r.description.isEmpty()) {
            TextView d = text(r.description, 13, TEXT, false);
            d.setPadding(0, dp(3), 0, dp(4));
            d.setMaxLines(3);
            card.addView(d);
        }
        StringBuilder meta = new StringBuilder("★ ").append(r.stars);
        if (!r.language.isEmpty()) meta.append(" · ").append(r.language);
        if (!r.license.isEmpty() && !r.license.equals("NOASSERTION")) meta.append(" · ").append(r.license);
        if (!r.updated.isEmpty()) meta.append(" · ").append(r.updated);
        card.addView(text(meta.toString(), 12, MUTED, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        card.setLayoutParams(lp);
        card.setOnClickListener(v -> repoDialog(r));
        return card;
    }

    private void repoDialog(final GitHub.Repo r) {
        String msg = (r.description.isEmpty() ? "Tanpa deskripsi." : r.description)
                + "\n\n★ " + r.stars
                + (r.language.isEmpty() ? "" : "\nBahasa: " + r.language)
                + (r.license.isEmpty() ? "" : "\nLisensi: " + r.license)
                + (r.updated.isEmpty() ? "" : "\nPembaruan terakhir: " + r.updated);
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(r.fullName)
                .setMessage(msg)
                .setPositiveButton("Buka di GitHub", (d, w) ->
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(r.url))))
                .setNeutralButton("File release", (d, w) -> loadReleases(r))
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void loadReleases(final GitHub.Repo r) {
        Toast.makeText(this, "Memuat release…", Toast.LENGTH_SHORT).show();
        pool.execute(() -> {
            try {
                final List<GitHub.Asset> assets = GitHub.releaseAssets(r.fullName);
                runOnUiThread(() -> {
                    if (assets.isEmpty()) {
                        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                                .setTitle(r.fullName)
                                .setMessage("Repo ini tidak punya file release. Kamu bisa membuka halaman GitHub-nya.")
                                .setPositiveButton("Buka", (d, w) ->
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(r.url))))
                                .setNegativeButton("Tutup", null)
                                .show();
                        return;
                    }
                    final String[] labels = new String[assets.size()];
                    for (int i = 0; i < labels.length; i++) {
                        GitHub.Asset a = assets.get(i);
                        labels[i] = a.name + "\n" + a.tag + " · " + mb(a.size);
                    }
                    new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                            .setTitle("Unduh dari release")
                            .setItems(labels, (d, which) -> enqueueDownload(assets.get(which)))
                            .setNegativeButton("Tutup", null)
                            .show();
                });
            } catch (Exception e) {
                final String m = friendly(e);
                runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
            }
        });
    }

    private void enqueueDownload(GitHub.Asset a) {
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 8);
            Toast.makeText(this, "Izinkan akses penyimpanan, lalu pilih file lagi.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(a.url));
            req.setTitle(a.name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "SegelPack/" + safeName(a.name));
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(req);
            Toast.makeText(this, "Mengunduh " + a.name + " ke Download/SegelPack", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Unduhan gagal dimulai.", Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------ helpers
    private void busy(boolean on) {
        pingBtn.setEnabled(!on);
        fetchBtn.setEnabled(!on);
        pingBtn.setAlpha(on ? 0.5f : 1f);
        fetchBtn.setAlpha(on ? 0.5f : 1f);
    }

    private void setStatus(String s, boolean error) {
        statusView.setText(s);
        statusView.setTextColor(error ? DANGER : MUTED);
    }

    private String friendly(Exception e) {
        if (e instanceof java.net.UnknownHostException) return "Nama host tidak ditemukan atau tidak ada internet.";
        if (e instanceof java.net.ConnectException) return "Koneksi ditolak. Cek IP dan port.";
        if (e instanceof java.net.SocketTimeoutException) return "Server tidak menjawab. Cek IP, port, dan apakah server menyala.";
        String m = e.getMessage();
        return m == null || m.isEmpty() ? "Terjadi kesalahan." : m;
    }

    private void copy(String t) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("pack", t));
        Toast.makeText(this, "Tautan tersalin", Toast.LENGTH_SHORT).show();
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    private static String mb(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private static String safeName(String s) {
        String t = s.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (t.isEmpty()) t = "pack";
        return t.length() > 60 ? t.substring(0, 60) : t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, MUTED, false);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.parseColor("#5B6B63"));
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(rounded(CARD, LINE, 10));
        e.setMinHeight(dp(48));
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(48)));
        return e;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(primary ? Color.parseColor("#06210F") : TEXT);
        b.setBackground(rounded(primary ? ACCENT : CARD, primary ? ACCENT : LINE, 10));
        return b;
    }

    private Button chip(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setTextColor(TEXT);
        b.setBackground(rounded(CARD, LINE, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
        lp.rightMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void styleChip(Button b, boolean on) {
        b.setTextColor(on ? Color.parseColor("#06210F") : TEXT);
        b.setBackground(rounded(on ? ACCENT : CARD, on ? ACCENT : LINE, 18));
    }

    private Button tabButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        return b;
    }

    private void styleTab(Button b, boolean on) {
        b.setTextColor(on ? ACCENT : MUTED);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.TRANSPARENT);
        b.setBackground(on ? underline() : null);
    }

    private android.graphics.drawable.Drawable underline() {
        GradientDrawable fill = new GradientDrawable();
        fill.setColor(Color.TRANSPARENT);
        GradientDrawable bar = new GradientDrawable();
        bar.setColor(ACCENT);
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{fill, bar});
        ld.setLayerInset(1, 0, dp(41), 0, 0);
        return ld;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(rounded(CARD, LINE, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        c.setLayoutParams(lp);
        return c;
    }

    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }
}
