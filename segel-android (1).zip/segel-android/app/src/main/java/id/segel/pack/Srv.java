package id.segel.pack;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Cari rekaman SRV _minecraft._tcp lewat DNS-over-HTTPS (Android tidak punya JNDI). */
public final class Srv {
    public static final class Target {
        public String host;
        public int port;
    }

    static final Pattern DATA = Pattern.compile("\"data\"\\s*:\\s*\"(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+([^\"\\s]+?)\\.?\"");

    public static Target parse(String json) {
        Matcher m = DATA.matcher(json);
        if (!m.find()) return null;
        Target t = new Target();
        t.port = Integer.parseInt(m.group(3));
        t.host = m.group(4);
        if (t.host.isEmpty() || t.host.equals(".") || t.port <= 0 || t.port > 65535) return null;
        return t;
    }

    public static boolean looksLikeIp(String host) {
        return host.matches("\\d{1,3}(\\.\\d{1,3}){3}") || host.contains(":");
    }

    /** Mengembalikan null bila tidak ada SRV atau gagal (aman diabaikan). */
    public static Target lookup(String host) {
        if (looksLikeIp(host) || !host.contains(".")) return null;
        try {
            String q = URLEncoder.encode("_minecraft._tcp." + host, "UTF-8");
            URL u = new URL("https://cloudflare-dns.com/dns-query?name=" + q + "&type=SRV");
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            c.setRequestProperty("Accept", "application/dns-json");
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            return parse(sb.toString());
        } catch (Exception e) {
            return null;
        }
    }
}
