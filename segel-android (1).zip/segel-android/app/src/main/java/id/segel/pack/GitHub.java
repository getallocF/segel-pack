package id.segel.pack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Klien GitHub REST API tanpa login (batas sekitar 10 pencarian per menit). */
public final class GitHub {

    public static final class Repo {
        public String fullName = "";
        public String description = "";
        public int stars;
        public String language = "";
        public String url = "";
        public String updated = "";
        public String license = "";
    }

    public static final class Asset {
        public String tag = "";
        public String name = "";
        public String url = "";
        public long size;
    }

    private static String str(JSONObject o, String key) {
        return o.isNull(key) ? "" : o.optString(key, "");
    }

    private static String get(String urlText) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "SegelPack-Android");
        int code = c.getResponseCode();
        if (code == 403 || code == 429) {
            throw new IOException("Batas pencarian GitHub tercapai. Tunggu sekitar satu menit lalu coba lagi.");
        }
        if (code == 422) throw new IOException("Kata kunci tidak valid untuk GitHub.");
        if (code < 200 || code >= 300) throw new IOException("GitHub menjawab HTTP " + code + ".");
        InputStream in = c.getInputStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        } finally {
            c.disconnect();
        }
        return sb.toString();
    }

    public static List<Repo> search(String query, String sort) throws IOException {
        String s = "best".equals(sort) ? "" : "&sort=" + sort + "&order=desc";
        String json = get("https://api.github.com/search/repositories?q=" + URLEncoder.encode(query, "UTF-8")
                + s + "&per_page=30");
        List<Repo> out = new ArrayList<>();
        try {
            JSONArray items = new JSONObject(json).getJSONArray("items");
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                Repo r = new Repo();
                r.fullName = str(o, "full_name");
                r.description = str(o, "description");
                r.stars = o.optInt("stargazers_count", 0);
                r.language = str(o, "language");
                r.url = str(o, "html_url");
                String up = str(o, "pushed_at");
                r.updated = up.length() >= 10 ? up.substring(0, 10) : up;
                if (!o.isNull("license")) r.license = str(o.getJSONObject("license"), "spdx_id");
                out.add(r);
            }
        } catch (JSONException e) {
            throw new IOException("Jawaban GitHub tidak terbaca.");
        }
        return out;
    }

    public static List<Asset> releaseAssets(String fullName) throws IOException {
        String json = get("https://api.github.com/repos/" + fullName + "/releases?per_page=3");
        List<Asset> out = new ArrayList<>();
        try {
            JSONArray rels = new JSONArray(json);
            for (int i = 0; i < rels.length(); i++) {
                JSONObject rel = rels.getJSONObject(i);
                String tag = str(rel, "tag_name");
                JSONArray assets = rel.optJSONArray("assets");
                if (assets == null) continue;
                for (int j = 0; j < assets.length(); j++) {
                    JSONObject a = assets.getJSONObject(j);
                    Asset x = new Asset();
                    x.tag = tag;
                    x.name = str(a, "name");
                    x.url = str(a, "browser_download_url");
                    x.size = a.optLong("size", 0);
                    if (!x.url.isEmpty()) out.add(x);
                }
            }
        } catch (JSONException e) {
            throw new IOException("Jawaban GitHub tidak terbaca.");
        }
        return out;
    }
}
